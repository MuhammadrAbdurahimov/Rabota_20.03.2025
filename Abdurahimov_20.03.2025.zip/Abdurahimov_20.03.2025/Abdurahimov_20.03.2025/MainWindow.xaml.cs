﻿using System.Windows;
using System.Windows.Controls;
using System.Linq;
using System.Collections.Generic;
using Abdurahimov_20._03._2025.Moduls;

namespace Abdurahimov_20._03._2025
{
    public partial class MainWindow : Window
    {
        private LibraryEntities _context = new LibraryEntities(); // EF-контекст
        private List<Books> _books; // Все книги из БД

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        // Загрузка данных из базы
        private void LoadData()
        {
            _books = _context.Books.ToList();
            BooksGrid.ItemsSource = _books;

            // Жанры
            var genres = _books.Select(b => b.Genre).Distinct().ToList();
            genres.Insert(0, "Все жанры");
            GenreFilter.ItemsSource = genres;
            GenreFilter.SelectedIndex = 0;
        }

        // События
        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilters();

        private void GenreFilter_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilters();

        private void SortBox_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilters();

        // Применение фильтров, поиска и сортировки
        private void ApplyFilters()
        {
            var filtered = _books.AsEnumerable();

            // Поиск
            string search = SearchBox.Text.ToLower();
            if (!string.IsNullOrWhiteSpace(search))
            {
                filtered = filtered.Where(b =>
                    b.Title.ToLower().Contains(search) ||
                    b.Author.ToLower().Contains(search));
            }

            // Фильтр по жанру
            string selectedGenre = GenreFilter.SelectedItem as string;
            if (!string.IsNullOrEmpty(selectedGenre) && selectedGenre != "Все жанры")
            {
                filtered = filtered.Where(b => b.Genre == selectedGenre);
            }

            // Сортировка
            if (SortBox.SelectedItem is ComboBoxItem selectedSort)
            {
                switch (selectedSort.Content.ToString())
                {
                    case "Название":
                        filtered = filtered.OrderBy(b => b.Title);
                        break;
                    case "Автор":
                        filtered = filtered.OrderBy(b => b.Author);
                        break;
                    case "Год":
                        filtered = filtered.OrderBy(b => b.Year);
                        break;
                }
            }

            BooksGrid.ItemsSource = filtered.ToList();
        }
    }
}
